/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Clock, CheckCircle2, ShieldCheck } from 'lucide-react';

export default function App() {
  const [timeLeft, setTimeLeft] = useState(238); // 3:58 in seconds

  useEffect(() => {
    if (timeLeft <= 0) return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-[#f9f9f9] dotted-bg font-sans text-gray-800 selection:bg-red-100">
      {/* Top Bar */}
      <div className="bg-red-600 text-white py-2 px-4 flex items-center justify-center gap-2 text-[10px] md:text-xs font-black uppercase tracking-[0.2em]">
        <span className="opacity-80">🔥</span>
        Oferta válida somente hoje
        <span className="opacity-80">🔥</span>
      </div>

      {/* Header Section */}
      <header className="pt-12 pb-8 px-4 text-center max-w-4xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-block bg-red-50 border-l-4 border-red-600 px-6 py-3 mb-8"
        >
          <span className="text-red-700 font-bold tracking-wide text-sm md:text-base">
            Espera — preparamos algo só pra você
          </span>
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-4xl md:text-6xl font-black text-gray-900 leading-[1.1] mb-8 tracking-tighter"
        >
          Antes de ir embora, seu filho merece <br />
          <span className="relative inline-block px-6 py-2 mt-4">
            <span className="absolute inset-0 bg-red-600 -rotate-1 transform skew-x-[-3deg]"></span>
            <span className="relative text-white uppercase italic">pelo menos uma chance</span>
          </span>
        </motion.h1>

        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed"
        >
          Sabemos que você estava interessada. Por isso criamos uma condição que não voltamos a oferecer depois que você fechar essa janela.
        </motion.p>
      </header>

      {/* Main Content / Pricing Card */}
      <main className="max-w-5xl mx-auto px-4 pb-20">
        <div className="flex flex-col md:flex-row items-center justify-center gap-12">
          
          {/* Product Image & Testimonial */}
          <div className="flex flex-col gap-6 w-full max-w-md">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="bg-red-600 p-6 rounded-[2rem] shadow-2xl relative text-white"
            >
              <p className="italic text-sm md:text-base leading-relaxed font-medium">
                "Fiquei na dúvida no preço. Aí vi essa oferta e comprei. Minha filha ficou uma hora fazendo experimentos sem pedir o celular uma vez."
              </p>
              <div className="mt-4 flex items-center gap-3">
                <img 
                  src="https://i.ibb.co/dZc3HCJ/Personagem-14-Copia.jpg" 
                  alt="Camila R." 
                  className="w-12 h-12 rounded-full object-cover border-2 border-white/30 shadow-lg"
                  referrerPolicy="no-referrer"
                />
                <p className="text-xs font-bold leading-tight">
                  <span className="block text-sm">Camila R.</span>
                  <span className="text-white/80 font-medium">mãe do Miguel, 7 anos</span>
                </p>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
              className="w-full aspect-square bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 to-transparent pointer-events-none" />
              <img 
                src="https://i.ibb.co/LzJJz4kg/Capa-da-VEGA.png" 
                alt="Capa da VEGA" 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
            </motion.div>
          </div>

          {/* Pricing & Benefits */}
          <div className="flex flex-col gap-8 w-full max-w-md">
            {/* Pricing Card */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.8, type: 'spring' }}
              className="bg-white rounded-3xl shadow-xl border border-gray-100 p-8 relative overflow-hidden"
            >
              {/* Discount Badge */}
              <div className="absolute top-0 right-0">
                <div className="bg-yellow-400 text-black font-black text-xs px-10 py-1 rotate-45 translate-x-8 translate-y-4 shadow-sm">
                  -81% OFF
                </div>
              </div>

              <div className="text-center space-y-4">
                <p className="text-black line-through text-lg decoration-red-600 decoration-2">
                  De R$ 27,00
                </p>
                <div className="flex flex-col items-center justify-center -space-y-2">
                  <span className="text-gray-700 font-bold text-xl">Por APENAS</span>
                  <span className="text-green-600 text-7xl font-black tracking-tighter">R$ 5,00</span>
                </div>

                <motion.a 
                  href="https://checkout.kiteureka.shop/VCCL1O8SCWRQ"
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ 
                    duration: 1.5, 
                    repeat: Infinity, 
                    ease: "easeInOut" 
                  }}
                  whileHover={{ scale: 1.08 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-black text-xl py-5 rounded-2xl shadow-lg shadow-red-600/20 transition-colors uppercase tracking-tight text-center block"
                >
                  Sim! Quero o Desconto
                </motion.a>

                <div className="flex items-center justify-center gap-2 text-red-600 bg-red-50 py-2 rounded-xl border border-red-100">
                  <Clock size={18} className="animate-pulse" />
                  <span className="font-bold text-sm">Oferta expira em: {formatTime(timeLeft)}</span>
                </div>
              </div>
            </motion.div>

            {/* Benefits List */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
              className="space-y-6"
            >
              <h3 className="text-xl font-black text-gray-900 uppercase tracking-tight flex items-center gap-2">
                O que você vai receber:
              </h3>
              <ul className="space-y-4">
                {[
                  "+150 cartas — 6 aventuras temáticas completas",
                  "Todas as versões de impressão (A4 / corte fácil / colorida / P&B econômica)",
                  "Acesso imediato pelo WhatsApp",
                  "Pronto para baixar e imprimir",
                  "Organizado por missão e aventura",
                  "Acesso vitalício",
                  "Garantia de 30 dias",
                  "Todos os 8 bônus exclusivos"
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-gray-700 font-medium">
                    <CheckCircle2 className="text-green-500 shrink-0" size={22} />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>

              <div className="pt-4 flex items-center gap-2 text-green-700 font-bold text-sm border-t border-gray-200">
                <ShieldCheck size={20} />
                <span>Compra 100% Segura e Garantida</span>
              </div>
            </motion.div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-12 border-t border-gray-200 text-center bg-white">
        <p className="text-gray-400 text-sm">
          © {new Date().getFullYear()} Sua Empresa. Todos os direitos reservados.
        </p>
      </footer>
    </div>
  );
}
